package all_servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mysql.cj.protocol.Resultset;

public class order extends HttpServlet {

	public static void main(String[] args) {}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	   resp.setContentType("text/html");
	   PrintWriter pw = resp.getWriter();
	   int id = Integer.parseInt(req.getParameter("id"));
	   String orderid =req.getParameter("orderid");
	   String productname = req.getParameter("productname");
	   String quantity =req.getParameter("quantity");
	   String address = req.getParameter("address");
	   String email =req.getParameter("email");
	   
	  pw.println(id);
	  pw.println(orderid);
	  pw.println(productname);
	  pw.println(quantity);
	  pw.println(address);
	  pw.println(email);
	   
	  Resultset rs;
	  try {
		  Connection connection=DatabaseConnection.ConnectoDb();
		  PreparedStatement pt =connection.prepareStatement("insert into orders(orderid,productname,quantity,address,email) values (?,?,?,?,?");
		  pt.setString(1, orderid);
		  pt.setString(2,productname);
		  pt.setString(3,quantity);
		  pt.setString(4,address);
		  pt.setString(5, email);
		  
		  pt.executeUpdate();
		  resp.sendRedirect("OrderView.jsp");
	  }catch(Exception e) {
		  e.printStackTrace();
		  e.getMessage();
	  }
	}
   
}
