package all_servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Register extends HttpServlet {

	public static void main(String[] args) {}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.setContentType("text/html");
		PrintWriter pw = resp.getWriter();
		String name=req.getParameter("name");
		String phone=req.getParameter("phone");
		String password=req.getParameter("password");
		String cpassword=req.getParameter("cpassword");
		if(password.equals(cpassword))
		{
			Connection connection=DatabaseConnection.ConnectoDb();
			String query="insert into emp(name,phone,password) values (?,?,?)";
			try {
				PreparedStatement ps =connection.prepareStatement(query);
				ps.setString(1, name);
				ps.setString(2, phone);
				ps.setString(3, cpassword);
				
				ps.executeUpdate();
				resp.sendRedirect("index.jsp");
			}catch(Exception e) {
				e.printStackTrace();
				e.getMessage();
			}
		}else {
			pw.println("password not matching");
		}
	}
}
